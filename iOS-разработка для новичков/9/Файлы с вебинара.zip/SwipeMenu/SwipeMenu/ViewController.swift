//
//  ViewController.swift
//  SwipeMenu
//
//  Created by Матвей Кавторов on 26.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var mainView: UIView!
    
    var isMenuShown = false
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func didSwipeRight(_ sender: UISwipeGestureRecognizer) {
        showMenu()
    }
    
    @IBAction func didSwipeLeft(_ sender: UISwipeGestureRecognizer) {
        hideMenu()
    }
    
    func hideMenu() {
        if isMenuShown {
            UIView.animate(withDuration: 0.3) {
                self.mainView.transform = self.mainView.transform.translatedBy(x: -200, y: 0)
            }
            isMenuShown = false
        }
    }
    
    func showMenu() {
        if !isMenuShown {
            UIView.animate(withDuration: 0.3) {
                self.mainView.transform = self.mainView.transform.translatedBy(x: 200, y: 0)
            }
            isMenuShown = true
        }
    }
    
    func toogleMenu() {
        if isMenuShown {
            hideMenu()
        } else {
            showMenu()
        }
    }
    
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 25
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = "\(indexPath.row+1) Позиция меню"
        return cell
    }
    
}

