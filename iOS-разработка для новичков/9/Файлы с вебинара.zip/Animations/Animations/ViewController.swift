//
//  ViewController.swift
//  Animations
//
//  Created by Матвей Кавторов on 26.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var testView: UIView!
    
    var originalTransform: CGAffineTransform!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        originalTransform = testView.transform
        // Do any additional setup after loading the view, typically from a nib.
//        tests()
    }
    
    @IBAction func rotate(_ sender: UIRotationGestureRecognizer) {
        if sender.state == .began {
            print("BEGAN")
            originalTransform = testView.transform
        } else if sender.state == .changed {
            testView.transform = originalTransform.rotated(by: sender.rotation)
        } else if sender.state == .ended {
            print("ENDED")
        }
    }
    
    @IBAction func pinch(_ sender: UIPinchGestureRecognizer) {
        if sender.state == .began {
            print("BEGAN")
            originalTransform = testView.transform
        } else if sender.state == .changed {
            testView.transform = originalTransform.scaledBy(x: sender.scale, y: sender.scale)
        } else if sender.state == .ended {
            print("ENDED")
        }
    }
    
    @IBAction func pan(_ sender: UIPanGestureRecognizer) {
        if sender.state == .began {
            print("BEGAN")
            originalTransform = testView.transform
        } else if sender.state == .changed {
            let point = sender.translation(in: testView)
            testView.transform = originalTransform.translatedBy(x: point.x, y: point.y)
        } else if sender.state == .ended {
            print("ENDED")
        }
    }
    
    @IBAction func animate() {
        UIView.animate(withDuration: 5) {
            // Финальное состояние объектов
            self.testView.backgroundColor = #colorLiteral(red: 0.8189184687, green: 0.0127219946, blue: 1, alpha: 1)
            
//            self.testView.frame.size.height = 300
            
//            self.testView.frame.origin.y -= 200
            
            //            self.view.frame.origin
            
//           self.testView.transform  = self.testView.transform.rotated(by: CGFloat.pi/2)
//            self.testView.transform  = self.testView.transform.translatedBy(x: 0, y: -100)
//            self.testView.frame.origin = .zero
//            self.testView.transform  = self.testView.transform.scaledBy(x: 2, y: 2)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tests() {
        func loadDataAndDo(something: (Data) -> ()) {
            print("Загружаем данные")
            something(Data())
        }
        
        loadDataAndDo { (data) in
            print(data)
        }
        
        let numbers = [1,2,3,4,5,6,7,8,9,0]
        print(numbers.filter { (number) -> Bool in
            return number % 3 == 0
        })
        print(numbers.sorted(by: { (number1, number2) -> Bool in
            return number1 > number2
        }))
        print(numbers.map({ (number) -> String in
            return "\(number)"
        }))
        numbers.forEach { (number) in
            print(number*2)
        }
    }

    @IBAction func handleTap(_ sender: UITapGestureRecognizer) {
        if self.testView.backgroundColor != #colorLiteral(red: 0.8189184687, green: 0.0127219946, blue: 1, alpha: 1) {
            UIView.animate(withDuration: 0.3) {
                self.testView.backgroundColor = #colorLiteral(red: 0.8189184687, green: 0.0127219946, blue: 1, alpha: 1)
            }
        } else {
            UIView.animate(withDuration: 0.3) {
                self.testView.backgroundColor = #colorLiteral(red: 0.03212521774, green: 1, blue: 3.330669074e-16, alpha: 1)
            }
        }
    }
    
}

