//
//  ViewController.swift
//  Player
//
//  Created by Матвей Кавторов on 09.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var authorLabel: UILabel!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var secondsLabel: UILabel!
    
    let playlist = [
        (name: "Smells Like Teen Spirit", author: "Nirvana", seconds: 277),
        (name: "Smoke On The Water", author: "Deep Purple", seconds: 340),
        (name: "Immigrant Song", author: "Led Zeppelin", seconds: 247),
        (name: "Long And Lonesome Road", author: "Shoking Blue", seconds: 165)
    ]
    
    var currentIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setSong(index: currentIndex)
    }
    
    func title(for seconds: Int) -> String {
        let min = seconds / 60
        let sec = seconds % 60
        if sec < 10 {
            return "\(min) : 0\(sec)"
        } else {
            return "\(min) : \(sec)"
        }
    }
    
    func setSong(index: Int) {
        let song = playlist[index]
        authorLabel.text = song.author
        titleLabel.text = song.name
        secondsLabel.text = title(for: song.seconds)
    }

    @IBAction func previous() {
        currentIndex -= 1
        if currentIndex == -1 {
            currentIndex = playlist.count - 1
        }
        setSong(index: currentIndex)
    }
    
    @IBAction func next() {
        currentIndex += 1
        if currentIndex == playlist.count {
            currentIndex = 0
        }
        setSong(index: currentIndex)
    }
    
}

