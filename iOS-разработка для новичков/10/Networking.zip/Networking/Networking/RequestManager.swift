//
//  RequestManager.swift
//  Networking
//
//  Created by Матвей Кавторов on 02.03.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import Foundation

import Alamofire

class RequestManager {
    private init(){}
    static let main = RequestManager()
    
    func loadTestData(completion: @escaping ([String: String]) -> ()) {
        let myUrl = URL(string: "http://matkavt.host22.com/json/test.json")!
        let session = URLSession.shared
        let task = session.dataTask(with: myUrl) { (optionalData, _, _) in
            if let data = optionalData {
                let decoder = JSONDecoder()
                do {
                    let result = try decoder.decode([String: String].self, from: data)
                    completion(result)
                } catch {
                    print("ОШИБКА")
                }
            }
        }
        task.resume()
    }
    
    func prettyLoadTestData(completion: @escaping ([String: String]) -> ()) {
        Alamofire.request("http://matkavt.host22.com/json/test.json").responseJSON { (response) in
            if let result = response.value as? [String: String] {
                completion(result)
            }
        }
    }
    
    func getNews(completion: @escaping ([News]) -> ()) {
        Alamofire.request("http://matkavt.host22.com/json/news.json").responseJSON { (response) in
            if let result = response.value as? [[String: String]] {
                var news: [News] = []
                for item in result {
                    if let oneNews = News(from: item) {
                        news.append(oneNews)
                    }
                }
                completion(news)
            }
        }
    }
    
    func getTemperature(in city: String, completion: @escaping (Double) -> ()) {
        let link = "https://api.openweathermap.org/data/2.5/weather?q=\(city)&apiKey=9015826a4bfd2a4af7fe7fe0fc673f71"
        Alamofire.request(link).responseJSON { (response) in
            if let result = response.value as? [String: Any?] {
                if let main = result["main"] as? [String: Any?] {
                    if let temp = main["temp"] as? Double {
                        completion(temp-273.15)
                    }
                }
            }
        }
    }
    
    func getSong(completion: @escaping (Data) -> ()) {
        let link = "http://matkavt.host22.com/json/song.mp3"
        Alamofire.request(link).responseData { (response) in
            if let data = response.data {
                completion(data)
            }
        }
    }
    
}
