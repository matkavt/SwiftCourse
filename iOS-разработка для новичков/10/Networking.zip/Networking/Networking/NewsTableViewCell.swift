//
//  NewsTableViewCell.swift
//  Networking
//
//  Created by Матвей Кавторов on 02.03.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

class NewsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var headerLabel: UILabel!

}
