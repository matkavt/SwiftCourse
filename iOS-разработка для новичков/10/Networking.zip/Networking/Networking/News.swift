//
//  News.swift
//  Networking
//
//  Created by Матвей Кавторов on 02.03.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import Foundation

struct News {
    var header: String
    var text: String
    
    init?(from dict: [String: Any?]) {
        if let header = dict["header"] as? String,
            let text = dict["text"] as? String {
            self.header = header
            self.text = text
        } else {
            return nil
        }
    }
}
