//
//  ViewController.swift
//  Networking
//
//  Created by Матвей Кавторов on 02.03.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

import AVFoundation

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var news: [News] = []
    
    var player: AVAudioPlayer?
    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        RequestManager.main.loadTestData { (result) in
//            DispatchQueue.main.async {
//                self.mainLabel.text = result["data"]
//            }
//        }
//    }
    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        RequestManager.main.prettyLoadTestData { (result) in
//            self.mainLabel.text = result["data"]
//        }
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        
        RequestManager.main.getTemperature(in: "London") { (temp) in
            print(temp)
        }
        
        RequestManager.main.getNews { (news) in
            self.news = news
            self.tableView.reloadData()
        }
        
        RequestManager.main.getSong { (songData) in
            self.player = try? AVAudioPlayer(data: songData)
            self.player?.play()
        }
        
    }


}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return news.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "newsCell") as! NewsTableViewCell
        let newsToShow = news[indexPath.row]
        cell.headerLabel.text = newsToShow.header
        cell.textView.text = newsToShow.text
        return cell
    }
    
}

