//
//  Song.swift
//  Player
//
//  Created by Матвей Кавторов on 23.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import Foundation

struct Song: Codable {
    var name: String
    var artist: String
    var lenth: Int
    
    var prettyLenth: String {
        let min = lenth / 60
        let sec = lenth % 60
        if sec < 10 {
            return "\(min) : 0\(sec)"
        } else {
            return "\(min) : \(sec)"
        }
    }
}
