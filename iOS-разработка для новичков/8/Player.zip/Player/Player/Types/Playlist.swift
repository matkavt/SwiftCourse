//
//  Playlist.swift
//  Player
//
//  Created by Матвей Кавторов on 23.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import Foundation

struct Playlist: Codable {
    var songs: [Song]
    var name: String
    
    func totalLenth() -> Int {
        var total = 0
        for song in songs {
            total += song.lenth
        }
        return total
    }
    
    var prettyTotalLenth: String {
        let tl = totalLenth()
        let min = tl / 60
        let sec = tl % 60
        if sec < 10 {
            return "\(min) : 0\(sec)"
        } else {
            return "\(min) : \(sec)"
        }
    }
}
