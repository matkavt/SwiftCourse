//
//  PlaylistTableViewCell.swift
//  Player
//
//  Created by Матвей Кавторов on 23.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

class PlaylistTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var totalLengthLabel: UILabel!
    
    @IBOutlet weak var numberOfSongsLabel: UILabel!
    
    func fill(with playlist: Playlist) {
        nameLabel.text = playlist.name
        totalLengthLabel.text = playlist.prettyTotalLenth
        numberOfSongsLabel.text = "Песен: \(playlist.songs.count)"
    }

}
