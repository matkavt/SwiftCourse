//
//  SongTableViewCell.swift
//  Player
//
//  Created by Матвей Кавторов on 23.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

class SongTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var artistLabel: UILabel!
    
    @IBOutlet weak var lengthLabel: UILabel!
    
    func fill(with song: Song) {
        nameLabel.text = song.name
        artistLabel.text = song.artist
        lengthLabel.text = song.prettyLenth
    }

}
