//
//  AddViewController.swift
//  Player
//
//  Created by Матвей Кавторов on 23.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

class AddViewController: UIViewController {
    
    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var srtistTextField: UITextField!
    
    @IBOutlet weak var lengthTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nameTextField.delegate = self
        srtistTextField.delegate = self
        lengthTextField.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func add() {
        if let name = nameTextField.text,
            let artist = srtistTextField.text,
            let lengthAsString = lengthTextField.text,
            let length = Int(lengthAsString) {
            let song = Song(name: name, artist: artist, lenth: length)
            let playlist = Playlist(songs: [song], name: "Новый плейлист")
            Archiver.main.add(new: playlist)
            
            let alert = UIAlertController(title: "Песня добавлена!", message: nil, preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
        } else {
            let alert = UIAlertController(title: "Ошибка!", message: "Вы ввели некорректные данные", preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .default, handler: nil)
            alert.addAction(action)
            present(alert, animated: true, completion: nil)
        }
    }
    
}

extension AddViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == nameTextField {
            nameTextField.resignFirstResponder()
            srtistTextField.becomeFirstResponder()
        } else if textField == srtistTextField {
            srtistTextField.resignFirstResponder()
            lengthTextField.becomeFirstResponder()
        } else {
            lengthTextField.resignFirstResponder()
        }
        return true
    }
    
}
