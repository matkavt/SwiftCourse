//
//  SongsViewController.swift
//  Player
//
//  Created by Матвей Кавторов on 23.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

class SongsViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var songs: [Song] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let indexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: indexPath, animated: true)
        }
        tableView.reloadData()
    }

}

extension SongsViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return songs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "songCell") as! SongTableViewCell
        cell.fill(with: songs[indexPath.row])
        return cell
    }
    
}

extension SongsViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let vc = storyboard?.instantiateViewController(withIdentifier: "songVC") as? SongViewController {
           vc.song = songs[indexPath.row]
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}
