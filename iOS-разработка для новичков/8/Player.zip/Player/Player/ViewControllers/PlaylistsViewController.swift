//
//  ViewController.swift
//  Player
//
//  Created by Матвей Кавторов on 23.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

class PlaylistsViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var playlists: [Playlist] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playlists = Archiver.main.getPlaylists()
//        Archiver.main.save(playlists: playlists)
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let indexPath = tableView.indexPathForSelectedRow {
            tableView.deselectRow(at: indexPath, animated: true)
        }
        playlists = Archiver.main.getPlaylists()
        tableView.reloadData()
    }

}

extension PlaylistsViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return playlists.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "playlistCell") as! PlaylistTableViewCell
        cell.fill(with: playlists[indexPath.row])
        return cell
    }
    
}

extension PlaylistsViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let vc = storyboard?.instantiateViewController(withIdentifier: "songsVC") as? SongsViewController {
            
            vc.songs = playlists[indexPath.row].songs
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}
