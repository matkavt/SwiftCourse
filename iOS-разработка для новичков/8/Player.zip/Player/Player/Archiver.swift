//
//  Archiver.swift
//  Player
//
//  Created by Матвей Кавторов on 23.02.18.
//  Copyright © 2018 Матвей Кавторов. All rights reserved.
//

import UIKit

class Archiver {
    private init(){}
    static let main = Archiver()
    
    private let encoder = PropertyListEncoder()
    private let decoder = PropertyListDecoder()
    private let defaults = UserDefaults.standard
    
    func getPlaylists() -> [Playlist] {
        if let data = defaults.data(forKey: "playlistsData") {
            if let playlists = try? decoder.decode([Playlist].self, from: data) {
                return playlists
            }
            return []
        }
        return []
    }
    
    func save(playlists: [Playlist]) {
        if let data = try? encoder.encode(playlists) {
            defaults.set(data, forKey: "playlistsData")
        }
    }
    
    func add(new playlist: Playlist) {
        var playlists = getPlaylists()
        playlists.append(playlist)
        save(playlists: playlists)
    }
    
}
